import httpx

from terminal.providers.gdelt_news import GdeltNewsProvider


class FakeResponse:
    def __init__(self, payload):
        self.payload = payload

    def raise_for_status(self):
        return None

    def json(self):
        return self.payload


def test_gdelt_news_parses_source_linked_headlines_and_caches():
    calls = []

    def request(url, **kwargs):
        calls.append((url, kwargs))
        return FakeResponse({"articles": [{
            "title": "Company announces results",
            "url": "https://publisher.example/story",
            "domain": "publisher.example",
            "seendate": "20261013T101500Z",
            "language": "English",
            "sourcecountry": "India",
        }, {"title": "Bad row", "url": "javascript:alert(1)"}]})

    provider = GdeltNewsProvider(request=request)
    result = provider.search("RELIANCE", max_records=10)
    cached = provider.search("RELIANCE", max_records=10)

    assert result["status"] == "AVAILABLE"
    assert result["count"] == 1
    assert result["data"][0]["url"] == "https://publisher.example/story"
    assert result["data"][0]["published_at"] == "2026-10-13T10:15:00+00:00"
    assert cached["cache_hit"] is True
    assert len(calls) == 1
    assert calls[0][1]["params"]["mode"] == "ArtList"
    assert calls[0][1]["params"]["timespan"] == "1day"


def test_gdelt_news_paces_distinct_searches():
    provider = GdeltNewsProvider(request=lambda *args, **kwargs: FakeResponse({"articles": []}))
    first = provider.search("NSE")
    second = provider.search("NIFTY")

    assert first["status"] == "NO_RESULTS"
    assert second["status"] == "UNAVAILABLE"
    assert "pacing" in second["reason"].lower()


def test_gdelt_rate_limit_is_explicit_not_fabricated():
    def rate_limited(*args, **kwargs):
        response = httpx.Response(
            429,
            request=httpx.Request("GET", "https://api.gdeltproject.org/api/v2/doc/doc"),
        )
        return response

    result = GdeltNewsProvider(request=rate_limited).search("NSE")
    assert result["status"] == "UNAVAILABLE"
    assert result["data"] == []
    assert "HTTP 429" in result["reason"]
