"""Small, cached GDELT DOC news-search adapter (headlines/links only).

This is a global-news discovery feed, not an exchange calendar or a market-data
provider. It never drives a buy/sell decision.
"""
from __future__ import annotations

import re
import threading
import time
from datetime import datetime, timezone
from typing import Any

import httpx


class GdeltNewsProvider:
    name = "GDELT DOC 2.0 (global news search)"
    endpoint = "https://api.gdeltproject.org/api/v2/doc/doc"
    cache_ttl_seconds = 900
    minimum_request_interval_seconds = 5.0

    def __init__(self, request=None):
        self._request = request or httpx.get
        self._lock = threading.RLock()
        self._cache: dict[str, tuple[float, dict[str, Any]]] = {}
        self._last_request_at = 0.0
        self._last_success_at: str | None = None
        self._last_error: str | None = None

    @staticmethod
    def _clean_query(query: str | None) -> str:
        value = (query or "(NSE OR NIFTY OR BSE)").strip()
        value = re.sub(r"[^A-Za-z0-9 .&'()\-]", " ", value)
        value = re.sub(r"\s+", " ", value).strip()[:120]
        return value or "(NSE OR NIFTY OR BSE)"

    @staticmethod
    def _parse_time(value: Any) -> str | None:
        text = str(value or "").strip()
        if not text:
            return None
        for fmt in ("%Y%m%dT%H%M%SZ", "%Y-%m-%dT%H:%M:%SZ"):
            try:
                return datetime.strptime(text, fmt).replace(tzinfo=timezone.utc).isoformat()
            except ValueError:
                continue
        return None

    def status(self) -> dict[str, Any]:
        return {
            "provider": self.name,
            "status": "DEGRADED" if self._last_error else ("CONNECTED_NEWS_ONLY" if self._last_success_at else "CONFIGURED_NOT_CHECKED"),
            "scope": "headline metadata and source links; no prices or official events",
            "cache_ttl_seconds": self.cache_ttl_seconds,
            "last_success_at": self._last_success_at,
            "last_error": self._last_error,
            "note": "GDELT is a global news index; headlines are not verified exchange disclosures or trading signals.",
        }

    def search(self, query: str | None = None, *, max_records: int = 20) -> dict[str, Any]:
        search_query = self._clean_query(query)
        cache_key = search_query.casefold()
        now = time.monotonic()
        with self._lock:
            cached = self._cache.get(cache_key)
            if cached and now - cached[0] < self.cache_ttl_seconds:
                return {**cached[1], "cache_hit": True}
            wait = self.minimum_request_interval_seconds - (now - self._last_request_at)
            if self._last_request_at and wait > 0:
                return {
                    "status": "UNAVAILABLE", "data": [], "source": self.name,
                    "source_timestamp": None, "received_at": datetime.now(timezone.utc).isoformat(),
                    "data_age_seconds": None,
                    "reason": "GDELT request pacing is active; retry after a few seconds or use the cached query.",
                    "query": search_query,
                }
            self._last_request_at = now

        try:
            response = self._request(
                self.endpoint,
                params={
                    "query": search_query,
                    "mode": "ArtList",
                    "format": "json",
                    "maxrecords": min(max(int(max_records), 1), 50),
                    "timespan": "1day",
                    "sort": "datedesc",
                },
                timeout=15.0,
            )
            response.raise_for_status()
            payload = response.json()
            raw_articles = payload.get("articles", []) if isinstance(payload, dict) else []
            articles: list[dict[str, Any]] = []
            for item in raw_articles if isinstance(raw_articles, list) else []:
                if not isinstance(item, dict):
                    continue
                title = str(item.get("title") or "").strip()
                url = str(item.get("url") or "").strip()
                if not title or not url.startswith(("https://", "http://")):
                    continue
                articles.append({
                    "title": title[:500],
                    "url": url,
                    "source_domain": str(item.get("domain") or "").strip(),
                    "published_at": self._parse_time(item.get("seendate")),
                    "language": str(item.get("language") or ""),
                    "source_country": str(item.get("sourcecountry") or ""),
                })
            timestamps = [item["published_at"] for item in articles if item.get("published_at")]
            result = {
                "status": "AVAILABLE" if articles else "NO_RESULTS",
                "data": articles,
                "source": self.name,
                "source_timestamp": max(timestamps) if timestamps else None,
                "received_at": datetime.now(timezone.utc).isoformat(),
                "data_age_seconds": None,
                "reason": None if articles else "No matching articles were returned by the GDELT index in the requested time window.",
                "query": search_query,
                "count": len(articles),
                "note": "Headline index only. Open the source article to verify facts; news is not a trading signal.",
                "cache_hit": False,
            }
            with self._lock:
                self._last_success_at = result["received_at"]
                self._last_error = None
                self._cache[cache_key] = (time.monotonic(), result)
            return result
        except httpx.HTTPStatusError as exc:
            self._last_error = f"HTTP_{exc.response.status_code}"
            detail = (
                "GDELT is rate-limiting this server (HTTP 429); retry later."
                if exc.response.status_code == 429
                else f"GDELT returned HTTP {exc.response.status_code}."
            )
            return {
                "status": "UNAVAILABLE", "data": [], "source": self.name,
                "source_timestamp": None, "received_at": datetime.now(timezone.utc).isoformat(),
                "data_age_seconds": None,
                "reason": f"{detail} No headlines were fabricated.",
                "query": search_query,
            }
        except (httpx.HTTPError, ValueError) as exc:
            self._last_error = type(exc).__name__
            return {
                "status": "UNAVAILABLE", "data": [], "source": self.name,
                "source_timestamp": None, "received_at": datetime.now(timezone.utc).isoformat(),
                "data_age_seconds": None,
                "reason": f"GDELT news search failed ({type(exc).__name__}); no headlines were fabricated.",
                "query": search_query,
            }
